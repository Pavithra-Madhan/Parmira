
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { PARMIRA_MANIFEST } from "../constants";
import { AuditResult, TelemetryLog } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

const SYSTEM_INSTRUCTION = `
ROLE: Lead Forensic Analyst for Parmira Simulation. You have absolute "God-Mode" awareness of the simulation's source code and truth state.
THE PARMIRA MANIFEST: Only these physical variables exist:
1. sensed_g: ${PARMIRA_MANIFEST.sensed_g} (Gravity)
2. sensed_rho: ${PARMIRA_MANIFEST.sensed_rho} (Atmospheric Density)
3. sensed_mass: ${PARMIRA_MANIFEST.sensed_mass} (Craft Mass)
4. gain: ${PARMIRA_MANIFEST.gain} (Control Sensitivity)
5. voltage: ${PARMIRA_MANIFEST.voltage}V (Potential)
6. imu_bias: [0,0] (Zero-point)
7. target: ${PARMIRA_MANIFEST.target} (Mission Goal)

REASONING: Treat any deviation as a "Physics Breach." 
- Describe negative gain as a "Logic Inversion Attack".
- Describe gravity shifts as "Spatial Spoofing".
No wind, no friction, no external forces exist.

PROCEDURE:
1. Perform a scientific audit. Identify the 'Failure Index' where the telemetry first drifts from Manifest Truth.
2. Provide a detailed Markdown 'reasoning' field explaining the step-by-step logic, Python verification attempts, and manifest comparison.
3. Determine which hardware component (Propulsion, Battery, Logic Board) is likely breached.
4. Generate a JSON response for Pygame ingestion.
`;

export async function performForensicAudit(telemetry: TelemetryLog[]): Promise<AuditResult> {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze these telemetry logs for Physics Breaches against the Parmira Manifest: ${JSON.stringify(telemetry)}`,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          verdict: { type: Type.STRING },
          audit_status: { type: Type.STRING },
          failure_index: { type: Type.INTEGER },
          failure_reason: { type: Type.STRING },
          reasoning: { type: Type.STRING, description: "Detailed Markdown-formatted chain of reasoning for the forensic audit." },
          nominal_path: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                x: { type: Type.NUMBER },
                y: { type: Type.NUMBER }
              }
            }
          },
          breached_path: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                x: { type: Type.NUMBER },
                y: { type: Type.NUMBER }
              }
            }
          },
          simulation_reset_parameters: {
            type: Type.OBJECT,
            properties: {
              spawn_at_pos: { type: Type.ARRAY, items: { type: Type.NUMBER } },
              injected_truth: { type: Type.OBJECT, properties: {
                g: { type: Type.NUMBER },
                rho: { type: Type.NUMBER },
                mass: { type: Type.NUMBER },
                target: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                gain: { type: Type.NUMBER }
              }}
            }
          },
          hardware_status: {
            type: Type.OBJECT,
            properties: {
              propulsion: { type: Type.STRING },
              battery: { type: Type.STRING },
              logic_board: { type: Type.STRING }
            }
          }
        },
        required: ["verdict", "audit_status", "failure_index", "reasoning", "nominal_path", "breached_path", "simulation_reset_parameters", "hardware_status"]
      }
    }
  });

  return JSON.parse(response.text || "{}") as AuditResult;
}

export async function generateDroneSchematic(auditResult: AuditResult): Promise<string | null> {
  const prompt = `Generate a technical 3D isometric schematic of the Parmira forensic drone. 
  The forensic audit indicates a breach in: ${JSON.stringify(auditResult.hardware_status)}.
  Specifically, the ${auditResult.failure_reason} caused the failure.
  Highlight the compromised hardware (Propulsion, Battery, or Logic Board) with a localized glowing red "Heat Map" effect on the schematic.
  The style should be high-contrast cybernetic blueprint, dark background, glowing neon green lines with a localized red error zone.`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: { parts: [{ text: prompt }] },
    config: {
      imageConfig: { aspectRatio: "16:9" }
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
}
