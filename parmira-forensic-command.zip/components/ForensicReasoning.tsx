
import React from 'react';

interface ForensicReasoningProps {
  content: string;
}

export const ForensicReasoning: React.FC<ForensicReasoningProps> = ({ content }) => {
  // Simple markdown-ish formatter
  const formatContent = (text: string) => {
    return text.split('\n').map((line, i) => {
      // Headers
      if (line.startsWith('### ')) {
        return <h4 key={i} className="text-[#00ff41] font-black uppercase tracking-widest text-xs mt-4 mb-2 border-b border-[#00ff41]/20 pb-1">{line.replace('### ', '')}</h4>;
      }
      if (line.startsWith('## ')) {
        return <h3 key={i} className="text-[#00ff41] font-black uppercase tracking-widest text-sm mt-6 mb-3 border-l-4 border-[#00ff41] pl-2">{line.replace('## ', '')}</h3>;
      }
      // Bold
      const boldFormatted = line.split(/(\*\*.*?\*\*)/).map((part, j) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return <strong key={j} className="text-white font-bold">{part.slice(2, -2)}</strong>;
        }
        return part;
      });
      
      return <p key={i} className="mb-2 leading-relaxed opacity-90">{boldFormatted}</p>;
    });
  };

  return (
    <div className="bg-black/80 border border-[#00ff41]/40 rounded-sm p-6 h-full flex flex-col gap-4 overflow-hidden group transition-all hover:border-[#00ff41]/60">
      <div className="flex justify-between items-center shrink-0">
        <h3 className="text-[#00ff41] text-[11px] font-black uppercase tracking-widest flex items-center gap-2">
          <span className="w-1.5 h-1.5 bg-[#00ff41] rounded-full animate-pulse shadow-[0_0_8px_#00ff41]"></span>
          Forensic Logic Chain
        </h3>
        <span className="text-[9px] text-[#00ff41]/40 font-mono">MD_RENDER_V1.0</span>
      </div>

      <div className="flex-grow overflow-y-auto pr-2 custom-scrollbar text-[11px] font-mono text-[#00ff41]/90">
        <div className="space-y-1">
          {formatContent(content)}
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(0, 255, 65, 0.05);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(0, 255, 65, 0.2);
          border-radius: 2px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(0, 255, 65, 0.4);
        }
      `}</style>
    </div>
  );
};
