
import React from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, ZAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { AuditResult } from '../types';

interface VisualizerProps {
  audit: AuditResult;
}

export const Visualizer: React.FC<VisualizerProps> = ({ audit }) => {
  const failurePoint = audit.breached_path[audit.failure_index];

  return (
    <div className="bg-black/60 border border-[#00ff41]/40 p-6 flex flex-col gap-6 rounded-sm shadow-2xl min-h-[450px]">
      <div className="flex justify-between items-center">
        <div className="flex flex-col gap-1">
          <h3 className="text-[#00ff41] text-[11px] font-black uppercase tracking-widest flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-[#00ff41] rounded-full animate-ping"></span>
            Spatial Delta Matrix
          </h3>
          <p className="text-[9px] text-[#00ff41]/40 uppercase tracking-tighter">Forensic Path Verification // 2D Projection</p>
        </div>
        <div className="flex gap-4">
          <div className="flex items-center gap-2 border border-[#00ff41]/20 px-2 py-1 rounded-sm bg-black/40">
            <div className="w-2 h-2 rounded-full bg-[#00ff41]"></div>
            <span className="text-[9px] font-bold tracking-tighter">MANIFEST</span>
          </div>
          <div className="flex items-center gap-2 border border-[#ff003c]/20 px-2 py-1 rounded-sm bg-black/40">
            <div className="w-2 h-2 rounded-full bg-[#ff003c]"></div>
            <span className="text-[9px] font-bold tracking-tighter">BREACHED</span>
          </div>
        </div>
      </div>

      <div className="flex-grow w-full relative group">
        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -20 }}>
            <CartesianGrid strokeDasharray="4 4" stroke="#00ff4115" vertical={false} />
            <XAxis 
              type="number" 
              dataKey="x" 
              hide={false}
              stroke="#00ff4130" 
              fontSize={9} 
              tick={{ fill: '#00ff4160' }}
              domain={[0, 1000]} 
              axisLine={false}
              tickLine={false}
            />
            <YAxis 
              type="number" 
              dataKey="y" 
              stroke="#00ff4130" 
              fontSize={9} 
              tick={{ fill: '#00ff4160' }}
              domain={[0, 1000]} 
              reversed 
              axisLine={false}
              tickLine={false}
            />
            <ZAxis type="number" range={[40, 40]} />
            <Tooltip 
              cursor={{ strokeDasharray: '2 2', stroke: '#00ff4140' }} 
              contentStyle={{ 
                backgroundColor: 'rgba(0, 0, 0, 0.9)', 
                border: '1px solid rgba(0, 255, 65, 0.4)', 
                borderRadius: '0',
                padding: '8px',
                fontSize: '10px',
                boxShadow: '0 0 15px rgba(0, 255, 65, 0.1)'
              }}
              itemStyle={{ color: '#00ff41', textTransform: 'uppercase', fontWeight: 'bold' }}
            />
            
            {/* Nominal Line */}
            <Scatter 
              name="Nominal" 
              data={audit.nominal_path} 
              fill="#00ff41" 
              line={{ stroke: '#00ff41', strokeWidth: 1.5, opacity: 0.8 }} 
              shape="circle"
              opacity={0.6}
            />

            {/* Breached Path */}
            <Scatter 
              name="Actual" 
              data={audit.breached_path} 
              fill="#ff003c" 
              line={{ stroke: '#ff003c', strokeWidth: 2, strokeDasharray: '3 3' }} 
              shape="cross" 
            />
            
            {/* Failure Marker */}
            {failurePoint && (
              <Scatter 
                data={[failurePoint]} 
                fill="#ff003c" 
                shape={(props: any) => {
                  const { cx, cy } = props;
                  return (
                    <g>
                      <circle cx={cx} cy={cy} r={12} fill="none" stroke="#ff003c" strokeWidth={1}>
                        <animate attributeName="r" from="8" to="24" dur="1.5s" repeatCount="indefinite" />
                        <animate attributeName="opacity" from="1" to="0" dur="1.5s" repeatCount="indefinite" />
                      </circle>
                      <circle cx={cx} cy={cy} r={4} fill="#ff003c" className="animate-pulse shadow-[0_0_10px_#ff003c]" />
                    </g>
                  );
                }}
              />
            )}
          </ScatterChart>
        </ResponsiveContainer>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-black/40 border border-[#00ff41]/20 p-4 rounded-sm flex flex-col justify-center">
          <span className="block text-[8px] text-[#00ff41]/40 mb-1 uppercase tracking-widest font-bold">Failure Node Index</span>
          <span className="text-2xl font-black tabular-nums tracking-tighter">0x{audit.failure_index.toString(16).toUpperCase().padStart(4, '0')}</span>
        </div>
        <div className="bg-black/40 border border-[#00ff41]/20 p-4 rounded-sm flex flex-col justify-center">
          <span className="block text-[8px] text-[#00ff41]/40 mb-1 uppercase tracking-widest font-bold">Anomaly Status</span>
          <span className={`text-sm font-black tracking-tighter uppercase ${audit.verdict === 'ANOMALY_DETECTED' ? 'text-[#ff003c] glow-text-red' : 'text-[#00ff41] glow-text'}`}>
            {audit.verdict.replace('_', ' ')}
          </span>
        </div>
      </div>
    </div>
  );
};
