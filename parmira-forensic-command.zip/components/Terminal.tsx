
import React from 'react';
import { LogEntry } from '../types';

interface TerminalProps {
  logs: LogEntry[];
}

export const Terminal: React.FC<TerminalProps> = ({ logs }) => {
  const terminalEndRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  return (
    <div className="bg-black/90 border border-[#00ff41]/30 h-[300px] overflow-y-auto p-4 font-mono text-[11px] terminal-scroll relative group flex-grow shadow-inner">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-[#00ff41]/10"></div>
      
      <div className="flex flex-col gap-1.5">
        {logs.length === 0 && (
          <div className="text-[#00ff41]/20 italic flex items-center gap-2">
            <span className="animate-pulse">_</span>
            Awaiting process execution...
          </div>
        )}
        {logs.map((log, i) => (
          <div key={i} className="flex gap-3 leading-relaxed border-l border-[#00ff41]/5 pl-2 hover:border-[#00ff41]/20 transition-colors">
            <span className="text-[#00ff41]/30 text-[9px] shrink-0 font-medium tabular-nums">[{log.timestamp}]</span>
            <div className={`flex gap-2 flex-grow
              ${log.type === 'error' ? 'text-[#ff003c]' : ''}
              ${log.type === 'success' ? 'text-[#00ff41] font-bold' : ''}
              ${log.type === 'python' ? 'text-blue-400 italic' : 'text-[#00ff41]/90'}
            `}>
              {log.type === 'python' && <span className="opacity-40 shrink-0 select-none">>>></span>}
              <span className="break-all">{log.message}</span>
            </div>
          </div>
        ))}
        <div ref={terminalEndRef} />
      </div>
    </div>
  );
};
