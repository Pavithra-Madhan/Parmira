
export interface TelemetryLog {
  timestamp: number;
  x: number;
  y: number;
  sensed_g?: number;
  sensed_rho?: number;
  sensed_mass?: number;
  gain?: number;
  voltage?: number;
  imu_bias?: [number, number];
}

export interface Manifest {
  sensed_g: number;
  sensed_rho: number;
  sensed_mass: number;
  gain: number;
  voltage: number;
  imu_bias: [number, number];
  target: [number, number];
}

export interface AuditResult {
  verdict: "ANOMALY_DETECTED" | "NOMINAL";
  audit_status: string;
  failure_index: number;
  failure_reason?: string;
  reasoning: string;
  nominal_path: { x: number; y: number }[];
  breached_path: { x: number; y: number }[];
  simulation_reset_parameters: {
    spawn_at_pos: [number, number];
    injected_truth: Partial<Manifest>;
  };
  hardware_status: {
    propulsion: "OK" | "CRITICAL";
    battery: "OK" | "CRITICAL";
    logic_board: "OK" | "CRITICAL";
  };
}

export interface LogEntry {
  type: 'info' | 'error' | 'success' | 'python';
  message: string;
  timestamp: string;
}
