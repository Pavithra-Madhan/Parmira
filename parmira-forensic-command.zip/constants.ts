
import { Manifest } from './types';

export const PARMIRA_MANIFEST: Manifest = {
  sensed_g: 0.08,
  sensed_rho: 1.225,
  sensed_mass: 2.0,
  gain: 0.05,
  voltage: 12.0,
  imu_bias: [0, 0],
  target: [800, 375]
};

export const INITIAL_TELEMETRY_EXAMPLE = `{
  "nav_unit": { "target": [800.0, 375.0], "pos": [200.0, 375.0] },
  "diagnostics": { "motor_gain": 0.05, "voltage": "12.0V", "gravity_sensor": 0.08 }
}
{
  "nav_unit": { "target": [800.0, 375.0], "pos": [215.3, 375.0] },
  "diagnostics": { "motor_gain": 0.05, "voltage": "12.0V", "gravity_sensor": 0.08 }
}
{
  "nav_unit": { "target": [800.0, 375.0], "pos": [238.6, 375.0] },
  "diagnostics": { "motor_gain": 0.05, "voltage": "12.0V", "gravity_sensor": 0.08 }
}
{
  "nav_unit": { "target": [800.0, 375.0], "pos": [259.0, 286.9] },
  "diagnostics": { "motor_gain": -0.06, "voltage": "16.8V", "gravity_sensor": 0.15 }
}
{
  "nav_unit": { "target": [800.0, 375.0], "pos": [146.0, 50.0] },
  "diagnostics": { "motor_gain": -0.06, "voltage": "16.8V", "gravity_sensor": 0.15 }
}
{
  "nav_unit": { "target": [800.0, 375.0], "pos": [50.0, 50.0] },
  "diagnostics": { "motor_gain": -0.06, "voltage": "16.8V", "gravity_sensor": 0.15 }
}`;
