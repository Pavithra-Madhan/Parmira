
import React, { useState } from 'react';
import { Terminal } from './components/Terminal';
import { Visualizer } from './components/Visualizer';
import { ForensicReasoning } from './components/ForensicReasoning';
import { PARMIRA_MANIFEST, INITIAL_TELEMETRY_EXAMPLE } from './constants';
import { TelemetryLog, AuditResult, LogEntry } from './types';
import { performForensicAudit, generateDroneSchematic } from './services/geminiService';

const App: React.FC = () => {
  const [telemetryInput, setTelemetryInput] = useState(INITIAL_TELEMETRY_EXAMPLE);
  const [isAuditing, setIsAuditing] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [auditResult, setAuditResult] = useState<AuditResult | null>(null);
  const [schematicUrl, setSchematicUrl] = useState<string | null>(null);
  const [iteration, setIteration] = useState(0);

  const addLog = (message: string, type: LogEntry['type'] = 'info') => {
    setLogs(prev => [...prev, {
      message,
      type,
      timestamp: new Date().toLocaleTimeString('en-GB', { hour12: false, minute: '2-digit', second: '2-digit' })
    }]);
  };

  const parseTelemetryInput = (input: string): TelemetryLog[] => {
    const trimmedInput = input.trim();
    
    // Check if it's a standard JSON array
    if (trimmedInput.startsWith('[') && trimmedInput.endsWith(']')) {
      try {
        return JSON.parse(trimmedInput);
      } catch (e) {
        throw new Error("Invalid JSON array format.");
      }
    }

    // Handle the "Multi-Object" or "JSON Stream" format
    // Matches { ... } blocks even if they are not comma separated
    const jsonBlocks = trimmedInput.match(/\{[\s\S]*?\}(?=\s*\{|$)/g);
    
    if (!jsonBlocks) {
      throw new Error("No valid JSON telemetry blocks detected.");
    }

    return jsonBlocks.map((block, index) => {
      try {
        const raw = JSON.parse(block);
        
        // Check for User's specific "nav_unit/diagnostics" structure
        if (raw.nav_unit && raw.diagnostics) {
          return {
            timestamp: index,
            x: raw.nav_unit.pos?.[0] ?? 0,
            y: raw.nav_unit.pos?.[1] ?? 0,
            gain: raw.diagnostics.motor_gain,
            voltage: raw.diagnostics.voltage ? parseFloat(raw.diagnostics.voltage) : undefined,
            sensed_g: raw.diagnostics.gravity_sensor,
            sensed_rho: PARMIRA_MANIFEST.sensed_rho,
            sensed_mass: PARMIRA_MANIFEST.sensed_mass
          };
        }
        
        // Fallback to existing TelemetryLog structure
        return raw as TelemetryLog;
      } catch (e) {
        console.warn(`Failed to parse telemetry block at index ${index}:`, e);
        return null;
      }
    }).filter((item): item is TelemetryLog => item !== null);
  };

  const runAudit = async () => {
    if (isAuditing) return;
    setIsAuditing(true);
    setAuditResult(null);
    setSchematicUrl(null);
    setIteration(0);
    setLogs([]);

    try {
      addLog("INITIALIZING FORENSIC COMMAND MODULE...", 'success');
      addLog(`PARMIRA MANIFEST LOADED: G=${PARMIRA_MANIFEST.sensed_g}, RHO=${PARMIRA_MANIFEST.sensed_rho}`, 'info');
      
      const parsedData = parseTelemetryInput(telemetryInput);
      addLog(`INGESTED ${parsedData.length} BLACKBOX TELEMETRY FRAMES (NORMALIZED)`, 'info');

      for (let i = 1; i <= 10; i++) {
        setIteration(i);
        addLog(`AGENTIC LOOP: PYTHON RE-FINEMENT ITERATION ${i}/10`, 'python');
        addLog(`audit_engine.verify(telemetry_stream, truth_manifest)`, 'python');
        await new Promise(r => setTimeout(r, 250));
        if (i < 10 && i % 3 === 0) addLog(`CONVERGENCE DELTA: ${(Math.random() * 0.01).toFixed(4)}. ADJUSTING...`, 'info');
      }

      addLog("AUDIT CONVERGED. PULLING TRUTH STATE FROM GEMINI-3-FLASH...", 'success');
      const result = await performForensicAudit(parsedData);
      setAuditResult(result);
      addLog(`VERDICT REACHED: ${result.verdict}`, result.verdict === 'ANOMALY_DETECTED' ? 'error' : 'success');
      addLog(`FAILURE IDENTIFIED AT INDEX ${result.failure_index}`, 'error');

      addLog("REQUESTING MULTIMODAL EVIDENCE FROM NANO BANANA...", 'info');
      const imageUrl = await generateDroneSchematic(result);
      setSchematicUrl(imageUrl);
      addLog("3D SCHEMATIC GENERATED WITH HEAT MAP OVERLAY.", 'success');
      
      addLog("GENERATING PYGAME OVERRIDE CONFIGURATION...", 'info');

    } catch (err: any) {
      addLog(`CRITICAL SYSTEM FAILURE: ${err.message}`, 'error');
      console.error(err);
    } finally {
      setIsAuditing(false);
    }
  };

  return (
    <div className="min-h-screen grid-bg p-4 md:p-6 lg:p-8 flex flex-col gap-6 text-[#00ff41]">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end border-b-2 border-[#00ff41] pb-6 bg-black/60 backdrop-blur-xl rounded-t-lg px-6 pt-6 shadow-[0_4px_30px_rgba(0,0,0,0.5)]">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl md:text-4xl font-black tracking-tighter glow-text uppercase">
              PARMIRA FORENSIC COMMAND
            </h1>
            <span className="hidden md:inline-block text-[10px] font-bold border border-[#00ff41] px-2 py-0.5 rounded animate-pulse bg-[#00ff41]/10">
              AUTONOMOUS LAB
            </span>
          </div>
          <p className="text-[10px] md:text-xs text-[#00ff41]/60 font-medium uppercase tracking-[0.2em]">
            Digital Twin Physics Breach Detector // VER 3.1-PRO-AI-CORE
          </p>
        </div>
        
        <div className="flex gap-6 mt-6 md:mt-0 font-mono">
          <div className="text-right border-l border-[#00ff41]/20 pl-4">
            <span className="block text-[9px] text-[#00ff41]/40 uppercase tracking-tighter font-bold">Gravity Threshold</span>
            <span className="font-bold text-lg md:text-2xl">{PARMIRA_MANIFEST.sensed_g}G</span>
          </div>
          <div className="text-right border-l border-[#00ff41]/20 pl-4">
            <span className="block text-[9px] text-[#00ff41]/40 uppercase tracking-tighter font-bold">Atmospheric Rho</span>
            <span className="font-bold text-lg md:text-2xl">{PARMIRA_MANIFEST.sensed_rho}</span>
          </div>
          <div className="text-right border-l border-[#00ff41]/20 pl-4">
            <span className="block text-[9px] text-[#00ff41]/40 uppercase tracking-tighter font-bold">System Voltage</span>
            <span className="font-bold text-lg md:text-2xl text-[#00ff41]">{PARMIRA_MANIFEST.voltage}V</span>
          </div>
        </div>
      </header>

      <main className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-grow overflow-hidden">
        <div className="lg:col-span-4 flex flex-col gap-6 h-full">
          <section className="bg-black/60 border border-[#00ff41]/40 p-4 rounded-sm flex flex-col gap-4 shadow-xl">
            <div className="flex justify-between items-center">
              <h2 className="text-[11px] font-black uppercase tracking-widest flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-[#00ff41] rounded-full shadow-[0_0_8px_#00ff41]"></span>
                Blackbox Input Stream
              </h2>
              <span className="text-[9px] text-[#00ff41]/40 font-mono">ENCRYPTED_LINK_ESTABLISHED</span>
            </div>
            <textarea
              className="w-full h-56 bg-black/80 border border-[#00ff41]/20 p-4 font-mono text-[11px] focus:border-[#00ff41] focus:ring-1 focus:ring-[#00ff41]/20 outline-none text-[#00ff41] transition-all resize-none leading-relaxed"
              value={telemetryInput}
              onChange={(e) => setTelemetryInput(e.target.value)}
              spellCheck={false}
              placeholder="Paste raw diagnostics or JSON array..."
            />
            <button
              onClick={runAudit}
              disabled={isAuditing}
              className={`group relative overflow-hidden py-4 font-black uppercase tracking-[0.2em] text-xs border border-[#00ff41] transition-all
                ${isAuditing ? 'bg-[#00ff41]/10 cursor-wait opacity-80' : 'hover:bg-[#00ff41] hover:text-black shadow-[0_0_20px_rgba(0,255,65,0.3)] active:scale-[0.98]'}`}
            >
              <span className="relative z-10">
                {isAuditing ? `ITERATING... (LOOP ${iteration}/10)` : 'Initialize Forensic Audit'}
              </span>
              {!isAuditing && <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#00ff41]/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>}
            </button>
          </section>

          <section className="flex-grow flex flex-col">
            <div className="flex justify-between items-center mb-2 px-1">
              <h2 className="text-[11px] font-black uppercase tracking-widest text-[#00ff41]/80">Execution Logs</h2>
              <span className="w-2 h-2 rounded-full bg-[#00ff41] animate-pulse"></span>
            </div>
            <Terminal logs={logs} />
          </section>
        </div>

        <div className="lg:col-span-8 flex flex-col gap-6 h-full min-h-[600px]">
          {auditResult ? (
            <div className="flex flex-col gap-6 h-full animate-in fade-in slide-in-from-right-4 duration-700">
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 min-h-[450px]">
                <Visualizer audit={auditResult} />
                
                <div className="bg-black/60 border border-[#00ff41]/40 p-6 flex flex-col gap-5 rounded-sm overflow-hidden group shadow-xl">
                  <div className="flex justify-between items-center">
                    <h3 className="text-[#00ff41] text-[11px] font-black uppercase tracking-widest flex items-center gap-2">
                      <span className="w-1.5 h-1.5 bg-[#ff003c] rounded-full animate-pulse shadow-[0_0_8px_#ff003c]"></span>
                      Multimodal Hardware Analysis
                    </h3>
                    <span className="text-[10px] text-[#ff003c]/60 font-mono">SOURCE: NANO_BANANA</span>
                  </div>
                  
                  <div className="flex-grow border border-[#00ff41]/20 flex items-center justify-center relative overflow-hidden min-h-[250px] bg-[#050505] rounded-sm group-hover:border-[#00ff41]/40 transition-colors">
                    <div className="absolute inset-0 pointer-events-none z-10 opacity-30">
                      <div className="h-0.5 w-full bg-[#00ff41] absolute animate-[scan_4s_ease-in-out_infinite]"></div>
                    </div>
                    
                    {schematicUrl ? (
                      <img src={schematicUrl} alt="Drone Schematic" className="max-w-full max-h-full object-contain p-2" />
                    ) : (
                      <div className="flex flex-col items-center gap-4">
                        <div className="w-12 h-12 border-2 border-[#00ff41] border-t-transparent rounded-full animate-spin"></div>
                        <div className="text-[10px] text-[#00ff41]/40 uppercase tracking-[0.3em]">Processing Visuals...</div>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    {['PROPULSION', 'BATTERY', 'LOGIC_BOARD'].map(part => {
                      const key = part.toLowerCase().replace(' ', '_') as keyof typeof auditResult.hardware_status;
                      const status = auditResult.hardware_status[key];
                      const isCritical = status === 'CRITICAL';
                      return (
                        <div key={part} className={`border p-3 rounded-sm transition-all flex flex-col items-center justify-center gap-1 shadow-inner
                          ${isCritical ? 'border-[#ff003c] bg-[#ff003c]/10 text-[#ff003c] animate-pulse' : 'border-[#00ff41]/20 bg-black/40 text-[#00ff41]/60'}`}>
                          <span className="text-[9px] font-black uppercase tracking-tighter whitespace-nowrap">{part.replace('_', ' ')}</span>
                          <span className="font-bold text-[13px]">{status}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 min-h-[300px]">
                <ForensicReasoning content={auditResult.reasoning} />

                <div className="bg-black/80 border-2 border-[#ff003c]/60 p-6 relative rounded-sm group overflow-hidden shadow-[0_0_30px_rgba(255,0,60,0.1)]">
                  <div className="absolute top-0 right-0 p-1 opacity-20 pointer-events-none group-hover:opacity-40 transition-opacity">
                     <div className="w-20 h-20 border-r-2 border-t-2 border-[#ff003c]"></div>
                  </div>
                  <div className="flex items-center gap-3 mb-4">
                     <span className="bg-[#ff003c] text-black text-[9px] font-black px-2 py-0.5 uppercase tracking-tighter">DATA BRIDGE</span>
                     <span className="text-[10px] font-bold text-[#ff003c] uppercase tracking-widest">Pygame Reset Manifest</span>
                  </div>
                  <div className="font-mono text-[11px] leading-relaxed text-[#ff003c]/90 bg-black/40 p-4 border border-[#ff003c]/20 rounded-sm h-[calc(100%-4rem)] overflow-y-auto custom-scrollbar">
                    <pre className="overflow-x-auto whitespace-pre-wrap">
                      {JSON.stringify({
                        verdict: auditResult.verdict,
                        failure_index: auditResult.failure_index,
                        simulation_reset_parameters: auditResult.simulation_reset_parameters
                      }, null, 2)}
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-grow border border-[#00ff41]/10 flex flex-col items-center justify-center min-h-[500px] text-[#00ff41]/20 bg-black/20 rounded-lg group shadow-inner">
              <div className="relative mb-8">
                <svg className="w-32 h-32 opacity-10 group-hover:opacity-30 transition-opacity animate-[spin_20s_linear_infinite]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="0.5">
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                   <div className="w-8 h-8 border border-[#00ff41]/40 rounded-full animate-ping"></div>
                </div>
              </div>
              <p className="text-sm font-black uppercase tracking-[0.4em] mb-2 glow-text opacity-40">System Idle</p>
              <p className="text-[10px] uppercase font-mono tracking-widest opacity-30">Awaiting Inbound Telemetry Stream...</p>
            </div>
          )}
        </div>
      </main>

      <footer className="mt-4 border-t border-[#00ff41]/10 pt-4 flex flex-col sm:flex-row justify-between items-center gap-4 text-[9px] text-[#00ff41]/30 font-bold uppercase tracking-[0.2em]">
        <div className="flex items-center gap-4">
          <span>© 2025 PARMIRA SIMULATION LABS</span>
          <span className="hidden sm:inline">|</span>
          <span className="text-[#00ff41]/50">SECURE COMMAND PORT: 8892</span>
        </div>
        <div className="flex items-center gap-6">
          <span className="flex items-center gap-1.5">
             <span className="w-1.5 h-1.5 bg-blue-500 rounded-full shadow-[0_0_5px_rgba(59,130,246,0.5)]"></span>
             UDP STABLE
          </span>
          <span className="flex items-center gap-1.5">
             <span className="w-1.5 h-1.5 bg-[#00ff41] rounded-full animate-pulse shadow-[0_0_5px_rgba(0,255,65,0.5)]"></span>
             AI CORE ONLINE
          </span>
        </div>
      </footer>

      <style>{`
        @keyframes scan {
          0%, 100% { top: 0% }
          50% { top: 100% }
        }
        .animate-spin-slow {
          animation: spin 8s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(0, 255, 65, 0.05);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(0, 255, 65, 0.2);
          border-radius: 2px;
        }
      `}</style>
    </div>
  );
};

export default App;
